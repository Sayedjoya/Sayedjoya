<?php

if(!function_exists('jio_token'))
{
    include('cmn.configs.php');
}
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    $identifier = ""; $password = ""; $method = "";
    if(isset($_POST['identifier'])){ $identifier = trim($_POST['identifier']); $identifier = str_replace(' ', '', $identifier);}
    if(isset($_POST['password'])){ $password = trim($_POST['password']); }
    if(isset($_POST['method'])){ $method = trim($_POST['method']); }
    
    if($method == "password")
    {
        if(empty($identifier))
        {
            api_res('error', 400, 'Please Enter Mobile Number / Email Address', '');
        }
        if(empty($password))
        {
            api_res('error', 400, 'Please Enter Password', '');
        }
        if(!is_valid_email($identifier)){ $identifier = '+91'.$identifier; }

        $zm_api = 'https://api.jio.com/v3/dip/user/unpw/verify';
        $zm_headers = array('user-agent: okhttp/3.14.9',
                            'os: android',
                            'devicetype: phone',
                            'content-type: application/json',
                            'x-api-key: l7xx938b6684ee9e4bbe8831a9a682b8e19f');
        $zm_payload = array('identifier' => $identifier,
                            'password' => $password,
                            'rememberUser' => 'T',
                            'upgradeAuth' => 'Y',
                            'returnSessionDetails' => 'T',
                            'deviceInfo' => array('consumptionDeviceName' => 'samsung SM-G930F',
                                                  'info' => array('type' => 'android',
                                                                  'platform' => array('name' => 'SM-G930F',
                                                                                      'version' => '5.1.1'),
                                                                  'androidId' => $ANDROID_ID)));
        $process = curl_init($zm_api);
        curl_setopt($process, CURLOPT_POST, 1);
        curl_setopt($process, CURLOPT_POSTFIELDS, json_encode($zm_payload));
        curl_setopt($process, CURLOPT_HTTPHEADER, $zm_headers); 
        curl_setopt($process, CURLOPT_HEADER, 0);
        curl_setopt($process, CURLOPT_TIMEOUT, 10);
        curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
        $zm_resp = curl_exec($process);
        curl_close($process);
        $zm_data = @json_decode($zm_resp, true);
        if(isset($zm_data['ssoToken']) && !empty($zm_data['ssoToken']))
        {
            //Success
            $save_jio = array('ssotoken' => $zm_data['ssoToken'], 'user' => $zm_data['sessionAttributes']['user']);
            if(file_put_contents('_isidata', hideit('encrypt', json_encode($save_jio))))
            {
                api_res('success', 200, 'Logged In Successfully', '');
            }
            else
            {
                api_res('error', 500, 'Logged In Successfully But Failed To Save Data', '');
            }
        }
        else
        {
            //Error
            api_res('error', 500, 'Failed To Login. Check Credentials.', '');
        }
    }
    elseif($method == "get_otp")
    {
        if(!preg_match('/^[0-9]{10}$/', $identifier)) 
        {
            api_res('error', 400, 'Please Enter Valid Mobile Number', '');
        }
        $zm_api = 'https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/send';
        $zm_headers = array('appname: RJIL_JioTV',
                            'os: android',
                            'devicetype: phone',
                            'content-type: application/json',
                            'user-agent: okhttp/3.14.9');
        $zm_payload = array('number' => base64_encode('+91'.$identifier));
        $process = curl_init($zm_api);
        curl_setopt($process, CURLOPT_POST, 1);
        curl_setopt($process, CURLOPT_POSTFIELDS, json_encode($zm_payload));
        curl_setopt($process, CURLOPT_HTTPHEADER, $zm_headers); 
        curl_setopt($process, CURLOPT_HEADER, 0);
        curl_setopt($process, CURLOPT_TIMEOUT, 10);
        curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
        $zm_resp = curl_exec($process);
        $zm_info = curl_getinfo($process);
        curl_close($process);
        $zm_data = @json_decode($zm_resp, true);
        if($zm_info['http_code'] == 204)
        {
            api_res('success', 200, 'OTP Sent Successfully', '');
        }
        else
        {
            if(isset($zm_data['message']))
            {
                api_res('error', 400, $zm_data['message'], '');
            }
            else
            {
                api_res('error', 500, 'Something Went Wrong', '');
            }
        }
    }
    elseif($method == "verify_otp")
    {
        if(!preg_match('/^[0-9]{10}$/', $identifier)) 
        {
            api_res('error', 400, 'Please Enter Valid Mobile Number', '');
        }
        if(empty($password))
        {
            api_res('error', 400, 'Please Enter OTP', '');
        }
        $zm_api = 'https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/verify';
        $zm_headers = array('appname: RJIL_JioTV',
                            'os: android',
                            'devicetype: phone',
                            'content-type: application/json',
                            'user-agent: okhttp/3.14.9');
        $zm_payload = '{"number":"'.base64_encode('+91'.$identifier).'","otp":"'.$password.'","deviceInfo":{"consumptionDeviceName":"RMX1945","info":{"type":"android","platform":{"name":"RMX1945"},"androidId":"'.$ANDROID_ID.'"}}}';
        $process = curl_init($zm_api);
        curl_setopt($process, CURLOPT_POST, 1);
        curl_setopt($process, CURLOPT_POSTFIELDS, $zm_payload);
        curl_setopt($process, CURLOPT_HTTPHEADER, $zm_headers); 
        curl_setopt($process, CURLOPT_HEADER, 0);
        curl_setopt($process, CURLOPT_TIMEOUT, 10);
        curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
        $zm_resp = curl_exec($process);
        $zm_info = curl_getinfo($process);
        curl_close($process);
        $zm_data = @json_decode($zm_resp, true);
        if(isset($zm_data['ssoToken']) && !empty($zm_data['ssoToken']))
        {
            //Success
            $save_jio = array('ssotoken' => $zm_data['ssoToken'], 'user' => $zm_data['sessionAttributes']['user']);
            if(file_put_contents('_isidata', hideit('encrypt', json_encode($save_jio))))
            {
                api_res('success', 200, 'Logged In Successfully', '');
            }
            else
            {
                api_res('error', 500, 'Logged In Successfully But Failed To Save Data', '');
            }
        }
        else
        {
            //Error
            api_res('error', 500, $zm_data['message'], '');
        }
    }
    else
    {
        api_res('error', 500, 'Unauthenticated Access', '');
    }
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Jio TV APP</title>
    <link rel="shortcut icon" href="../favicon.ico"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<style>
body
{
    font-weight: 400;
    background-color: #131720;
    -webkit-font-smoothing: antialiased;
    padding-top: 15px;
    padding-left: 15px;
    padding-right: 15px;
}
#mnop, #qrst, #uvwx, #qrst, #xxyyzz
{
    display: none;
}
#form_error_msg
{
    display: none;
    color: #088378;
    font-weight: bold;
}
#form_error_msg_2
{
    display: none;
    color: #088378;
    font-weight: bold;
}
</style>
</head>
<body>

<div class="card">
  <div class="card-body">
    <h6 class="card-title"><img src="../jio_logo.png" alt="JioTV" height="25" width="25"/>&nbsp;&nbsp;JioTV Login</h6>
    <p class="card-text"><hr/></p>
    
    <div class="mt-3">
        <button class="btn btn-danger btn-sm" id="enerme"> By Password </button>&nbsp;<button class="btn btn-sm btn-dark" id="anamro"> By OTP </button>
    </div>
    <div class="mt-3" id="form_error_msg"></div>
    <div class="mt-3" id="abcd">
        <input type="text" class="form-control" placeholder="Mobile Number / Email Address" id="jio_identifier" autocomplete="off"/>
    </div>
    <div class="mt-3" id="efgh">
        <input type="text" class="form-control" placeholder="Password" id="jio_password" autocomplete="off"/>
    </div>
    <div class="mt-3" id="ijkl">
    <button class="btn btn-success btn-sm" id="aonoa"> Login </button>
    </div>
    <div class="mt-3" id="mnop">
        <input type="text" class="form-control" id="zio_mobile" placeholder="Mobile Number" autocomplete="off"/>
    </div>
    <div class="mt-3" id="qrst">
        <input type="text" class="form-control" placeholder="OTP" id="zio_password" autocomplete="off"/>
    </div>
    <div class="mt-3" id="uvwx">
        <button class="btn btn-success btn-sm" id="cono" onclick="getotp()"> Get OTP </button>
    </div>
    <div class="spinner-border text-warning mt-3" role="status" id="xxyyzz">
        <span class="visually-hidden">Loading...</span>
    </div>
  </div>
</div>


<div class="card mt-4">
<div class="card-body">

    <h6 class="card-title"><img src="../jio_logo.png" alt="Jio TV Logo" height="25" width="25"/>&nbsp;&nbsp;JioTV Playlist Generation</h6>
    <p class="card-text"><hr/></p>
    
    <div class="mt-3" id="form_error_msg_2"></div>
    <div class="mt-3">
        <input type="text" id="adnowplys" readonly="" placeholder="Click Generate Button Below To Get Playlist Link" autocomplete="off" class="form-control"/>
    </div>
    <div class="mt-3">
        <button class="btn btn-danger btn-sm" id="dogenPlayz"> Generate Playlist </button>
    </div>
    
  </div>
</div>


<script src="../js/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
<script>
$("#enerme").on("click", function(){
    $("#mnop").hide();
    $("#qrst").hide();
    $("#uvwx").hide();
    $("#abcd").fadeIn();
    $("#efgh").fadeIn();
    $("#ijkl").fadeIn();
    $("#enerme").attr("class", "btn btn-danger btn-sm");
    $("#anamro").attr("class", "btn btn-dark btn-sm");
});
$("#anamro").on("click", function(){
    $("#abcd").hide();
    $("#efgh").hide();
    $("#ijkl").hide();
    $("#mnop").fadeIn();
    $("#uvwx").fadeIn();
    $("#anamro").attr("class", "btn btn-danger btn-sm");
    $("#enerme").attr("class", "btn btn-dark btn-sm");
});
$("#aonoa").on("click", function(){
    $("#form_error_msg").fadeOut();
    $("#ijkl").hide();
    $("#xxyyzz").fadeIn();
    let identifier = $("#jio_identifier").val();
    let password = $("#jio_password").val();
    $.ajax({
        "url": "",
        "type": "POST",
        "data": "identifier=" + identifier + "&password=" + password + "&method=password",
        "beforeSend":function(xhr)
        {

        },
        "success":function(data)
        {
            $("#xxyyzz").hide();
            $("#ijkl").fadeIn();
            try { data = JSON.parse(data); }catch(err){}
            if(data.status == "success")
            {
                show_success(data.msg);
                $("#jio_identifier").val('');
                $("#jio_password").val('');
            }
            else
            {
                if(data.status == "error")
                {
                    show_error(data.msg);
                }
                else
                {
                    show_error("Something Went Wrong");
                } 
            }
        },
        "error":function(data)
        {
            show_error("Failed To Connect");
        }
    });
});

function getotp()
{
    $("#uvwx").hide();
    $("#xxyyzz").fadeIn();
    let mobile = $("#zio_mobile").val();
    $.ajax({
        "url": "",
        "type": "POST",
        "data": "identifier=" + mobile + "&method=get_otp",
        "beforeSend":function(xhr)
        {

        },
        "success":function(data)
        {
            $("#xxyyzz").hide();
            $("#uvwx").fadeIn();
            try { data = JSON.parse(data); }catch(err){}
            if(data.status == "success")
            {
                show_success('Enter OTP Sent To Your Jio Phone Number');
                $("#qrst").fadeIn();
                let adam = '<button class="btn btn-success btn-sm" id="bihi" onclick="verifyotp()"> Verify OTP </button>';
                $("#uvwx").html(adam);
            }
            else
            {
                if(data.status == "error")
                {
                    show_error(data.msg);
                }
                else
                {
                    show_error("Something Went Wrong");
                } 
            }
        },
        "error":function(data)
        {
            show_error("Failed To Connect");
        }
    });
}

function verifyotp()
{
    $("#uvwx").hide();
    $("#xxyyzz").fadeIn();
    let mobile = $("#zio_mobile").val();
    let password = $("#zio_password").val();
    $.ajax({
        "url": "",
        "type": "POST",
        "data": "identifier=" + mobile + "&password=" + password + "&method=verify_otp",
        "beforeSend":function(xhr)
        {

        },
        "success":function(data)
        {
            $("#xxyyzz").hide();
            $("#uvwx").fadeIn();
            try { data = JSON.parse(data); }catch(err){}
            if(data.status == "success")
            {
                show_success('Logged In Successfully');
                $("#zio_mobile").val('');
                $("#zio_password").val('');
            }
            else
            {
                if(data.status == "error")
                {
                    show_error(data.msg);
                }
                else
                {
                    show_error("Something Went Wrong");
                } 
            }
        },
        "error":function(data)
        {
            show_error("Failed To Connect");
        }
    });
}

function show_error(error)
{
    $("#form_error_msg").css("color", "#088378");
    $("#form_error_msg").text(error);
    $("#form_error_msg").fadeIn();
}
function show_success(sue)
{
    $("#form_error_msg").css("color", "#088311");
    $("#form_error_msg").text(sue);
    $("#form_error_msg").fadeIn();
}

$("#dogenPlayz").on("click", function(){
    $("#dogenPlayz").attr("class", "btn btn-danger btn-sm");
    $("#dogenPlayz").text("Generate Playlist");
    $("#form_error_msg").fadeOut();
    $("#dogenPlayz").fadeOut();
    $.ajax({
        "url":"m3u_playlist.php",
        "data": "",
        "type":"GET",
        "beforeSend":function(xhr)
        {

        },
        "success":function(data)
        {
            $("#dogenPlayz").fadeIn();
            try { data = JSON.parse(data); }catch(err){}
            if(data.status == "success")
            {
                $("#dogenPlayz").attr("class", "btn btn-success btn-sm");
                $("#dogenPlayz").text("Playlist Generated");
                $("#adnowplys").val(data.data.playlist_link);
            }
            else
            {
                $("#form_error_msg_2").text(data.msg);
                $("#form_error_msg_2").fadeIn();
            }
        },
        "error":function(data)
        {
            $("#dogenPlayz").fadeIn();
            $("#form_error_msg_2").text("Failed To Connect");
            $("#form_error_msg_2").fadeIn();
        }
    });
});
</script>
</body>
</html>