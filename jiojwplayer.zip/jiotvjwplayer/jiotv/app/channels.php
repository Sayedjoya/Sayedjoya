<?php

//Jio TV Channel List

include('cmn.configs.php');

$page = 1;
$items_per_page = 60;
if(isset($_GET['page'])){ $page = $_GET['page']; }
$offset = ($page - 1) * $items_per_page;

//-----------------------------------------------------//

$get_refresh = "";
$items = array();
if(isset($_GET['force_refresh'])){ $get_refresh = $_GET['force_refresh']; }

if($get_refresh !== "yes")
{
    $getikd = @file_get_contents('_chndata');
    $imchnd = hideit('decrypt', $getikd);
    if(!empty($imchnd))
    {
        $ivbz = @json_decode($imchnd, true);
        if(!empty($ivbz))
        {
            $settledlk = array_slice($ivbz, $offset, $items_per_page);
            api_res('success', 200, 'OK (CACHED)', $settledlk);
        }
    }
}

//--------------------------------------------------------------//

$category = array('5' => 'Entertainment',
                  '6' => 'Movies',
                  '7' => 'Kids',
                  '8' => 'Sports',
                  '9' => 'Lifestyle',
                  '10' => 'Infotainment',
                  '12' => 'News',
                  '13' => 'Music',
                  '15' => 'Devotional',
                  '16' => 'Business',
                  '17' => 'Education',
                  '19' => 'Devotional');

$language = array('1' => 'Hindi',
                  '2' => 'Marathi',
                  '3' => 'Punjabi',
                  '4' => 'Urdu',
                  '5' => 'Bengali',
                  '6' => 'English',
                  '7' => 'Malayalam',
                  '8' => 'Tamil',
                  '9' => 'Gujarati',
                  '10' => 'Odia',
                  '11' => 'Telugu',
                  '12' => 'Bhojpuri',
                  '13' => 'Kannada',
                  '14' => 'Assamese',
                  '15' => 'Nepali',
                  '16' => 'French');

                  
$apiurl = 'http://jiotv.data.cdn.jio.com/apis/v1.3/getMobileChannelList/get/?langId=6&os=android&devicetype=phone&usergroup=tvYR7NSNn7rymo3F&version=6.0.9&langId=6';
$apihead[] = 'usergroup: tvYR7NSNn7rymo3F';
$apihead[] = 'appkey: NzNiMDhlYzQyNjJm';
$apihead[] = 'devicetype: phone';
$apihead[] = 'os: android';
$apihead[] = 'deviceId: 7c780a40d327f66';
$apihead[] = 'appversioncode: 262';
$apihead[] = 'appversion: 6.0.9';
$apihead[] = 'User-Agent: okhttp/3.14.9';
$process = curl_init($apiurl);
curl_setopt($process, CURLOPT_HTTPHEADER, $apihead);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_ENCODING, '');
curl_setopt($process, CURLOPT_TIMEOUT, 10);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
$return = curl_exec($process);
curl_close($process);
$imoi = @json_decode($return, true);

if(!empty($imoi['result']))
{
    foreach($imoi['result'] as $intv)
    {
        if(stripos($intv['channel_name'], 'test') === false)
        {
            if(stripos($intv['channel_name'], 'Star') === false)
            {
                $items[] = array('id' => str_replace('.png', '', $intv['logoUrl']),
                                 'title' => $intv['channel_name'],
                                 'logo' => 'https://jiotvweb.cdn.jio.com/jiotv.catchup.cdn.jio.com/dare_images/images/'.$intv['logoUrl'],
                                 'category' => str_replace(null, '', $category[$intv['channelCategoryId']]),
                                 'language' => str_replace(null, '', $language[$intv['channelLanguageId']]));
            }
        }
    }
}

if(!empty($items))
{
    @file_put_contents('_chndata', hideit('encrypt', json_encode($items)));
    $semtalz = array_slice($items, $offset, $items_per_page);
    api_res('success', 200, 'OK (CACHED)', $semtalz);
}
else
{
    api_res('error', 404, 'No Channels Found', '');
}


?>
