<?php

if(!function_exists('jio_token'))
{
    include('cmn.configs.php');
}

$id = "";
$chtvs = array();
$streamenvproto = "http";
$drmurl = ""; $playurl = "";

if(isset($_GET['id']))
{
    $id = $_GET['id'];
}

if(isset($_POST['id']))
{
    $id = $_POST['id'];
}

if(empty($id))
{
    api_res('error', 400, 'Channel ID Required', '');
}

if($_SERVER['HTTPS'] == "on")
{
    $streamenvproto = "https";
}

$getikd = @file_get_contents('_chndata');
$imchnd = hideit('decrypt', $getikd);
if(!empty($imchnd))
{
    $ivbz = @json_decode($imchnd, true);
    if(!empty($ivbz))
    {
        foreach($ivbz as $yad)
        {
            if($id == $yad['id'])
            {
                $chtvs = $yad;
            }
        }
    }
}

if(empty($imchnd))
{
    api_res('error', 400, 'Go Back To Homepage and Try Again', '');
}

if(empty($chtvs))
{
    api_res('error', 500, 'No Data Found For This Channel', '');
}

if(empty($JIO_AUTH))
{
    api_res('error', 401, 'Please Login To JioTV Account To Use This App', '');
}

$maURL = $streamenvproto.'://'.$_SERVER['HTTP_HOST'].':'.$_SERVER['SERVER_PORT'].str_replace(" ", "%20", trim(str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']).'master.php?id='.$chtvs['id'].'&e=.m3u8')).PHP_EOL;


$uoro = array('id' => $chtvs['id'],
              'title' => $chtvs['title'],
              'logo' => $chtvs['logo'],
              'category' => $chtvs['category'],
              'language' => $chtvs['language'],
              'playurl' => $maURL,
              'drmurl' => '',
              'type' => 'HLS');
api_res('success', 200, 'OK', $uoro);


?>