<?php

error_reporting(0);

date_default_timezone_set('Asia/Kolkata');

function android_id()
{
    $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
    $oixweu = hash('sha256', str_shuffle($permitted_chars).time().str_shuffle($permitted_chars));
    return substr($oixweu, 0, 16);
}

function inside_token($id)
{
    return sha1($id.time().'carbide').'_'.time();
}

function validateToken($id, $token)
{
    return true;
}

function jio_token()
{
    $time = time();
    return "jct=" . trim(str_replace("\n","",str_replace("\r","",str_replace("/","_",str_replace("+","-",str_replace("=","",base64_encode(md5("cutibeau2ic01b589574d7399b27f0e681450bc51f1" . (time() + 1200),true)))))))) . "&pxe=" . (time() + 1200) . "&st=01b589574d7399b27f0e681450bc51f1";
}

function add_logs($task)
{
    $logs_file = "mylogs";
    $logs_info = date('F d, Y h:i:s A').' - '.$task.' - '.$_SERVER['REMOTE_ADDR'].' - '.$_SERVER['HTTP_USER_AGENT'].PHP_EOL;
    $savify = fopen("$logs_file", "a");
    fwrite($savify, $logs_info);
    fclose($savify);
}

function hideit($action, $data)
{
    if(!file_exists('_andrid'))
    {
        @file_put_contents('_andrid', android_id());
    }
    $ANDROID_ID = @file_get_contents('_andrid');
    $aes_pass = sha1($ANDROID_ID.'xxyyzz');
    $key = substr($aes_pass, 0, 16);

    $response = "";
    $method = "aes-128-cbc";
    $iv = "lifeisaboutdares";
    if($action == "encrypt")
    {
        $encrypted = openssl_encrypt($data, $method, $key, OPENSSL_RAW_DATA, $iv);
        if(!empty($encrypted))
        {
            $response = bin2hex($encrypted);
        }
    }
    elseif($action == "decrypt")
    {
        $decrypted = openssl_decrypt(hex2bin($data), $method, $key, OPENSSL_RAW_DATA, $iv);
        if(!empty($decrypted))
        {
            $response = $decrypted;
        }
    }
    else{ }
    return $response;
}

function api_res($status, $code, $msg, $data)
{
    header("Content-Type: application/json");
    if($status == "success" || $status == "error")
    {
        if($status == "error"){ $data = array(); }
        $out = array('status' => $status, 'code' => $code, 'msg' => $msg, 'data' => $data);
        print(json_encode($out));
        exit();
    }
    else
    {
        http_response_code(500);
        exit();
    }
}


function is_valid_email($mail)
{
    return preg_match('/\A[a-z0-9]+([-._][a-z0-9]+)*@([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,4}\z/', $mail)
        && preg_match('/^(?=.{1,64}@.{4,64}$)(?=.{6,100}$).*/', $mail);
}
//-----------------------------------------------------------------------------//

if(!file_exists('_andrid'))
{
    @file_put_contents('_andrid', android_id());
}

$ANDROID_ID = @file_get_contents('_andrid');
$JIO_AUTH = array();
if(file_exists('_isidata'))
{
    $kair = @file_get_contents('_isidata');
    if(!empty($kair))
    {
        $kbir = hideit('decrypt', $kair);
        if(!empty($kbir))
        {
            $kwire = @json_decode($kbir, true);
            if(!empty($kwire))
            {
                $JIO_AUTH = $kwire;
            }
        }
    }
}

if(stripos($_SERVER['HTTP_HOST'], ':') !== false)
{
    $warl = explode(':', $_SERVER['HTTP_HOST']);
    if(isset($warl[0]) && !empty($warl[0]))
    {
        $_SERVER['HTTP_HOST'] = trim($warl[0]);
    }
}

if(stripos($_SERVER['HTTP_HOST'], 'localhost') !== false)
{
    $_SERVER['HTTP_HOST'] = str_replace('localhost', '127.0.0.1', $_SERVER['HTTP_HOST']);
}


?>