<?php

header("Access-Control-Allow-Origin: *");
if(!function_exists('jio_token'))
{
    include('cmn.configs.php');
}

$s = ""; $id = ""; $cdn = ""; $token = "";
if(isset($_GET['s'])){ $s = $_GET['s']; }
if(isset($_GET['id'])){ $id = $_GET['id']; }
if(isset($_GET['cdn'])){ $cdn = $_GET['cdn']; }
if(isset($_GET['token'])){ $token = $_GET['token']; }

if(empty($s))
{
    http_response_code(400); exit();
}

if(empty($id))
{
    http_response_code(400); exit();
}

validateToken($id, $token);

if(!empty($cdn))
{
    $playurl = 'https://'.$cdn.'/jiotv.live.cdn.jio.com/'.$id.'/'.$id.'_'.$s.'.m3u8';
}
else
{
    $playurl = 'https://jiotv.live.cdn.jio.com/'.$id.'/'.$id.'_'.$s.'.m3u8';
}

$playhead = array('User-Agent: KAIOS');
$process = curl_init($playurl);
curl_setopt($process, CURLOPT_HTTPHEADER, $playhead);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_ENCODING, '');
curl_setopt($process, CURLOPT_TIMEOUT, 15);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
$return = curl_exec($process);
$final_url = curl_getinfo($process, CURLINFO_EFFECTIVE_URL);
curl_close($process);
$base_url = str_replace(basename($final_url), '', $final_url);

if(stripos($return, '#EXTM3U') !== false)
{
    $repkey = 'https://tv.media.jio.com/streams_live/'.$id.'/'.$id.'_'.$s.'-';
    $vb_fix = str_replace($repkey, 'keyman.php?token='.$_GET['token'].'&id='.$id.'&s='.$s.'&k=', $return);
    if(empty($cdn))
    {
        $vb_fix = str_replace($id.'_'.$s.'-', $base_url.$id.'_'.$s.'-', $vb_fix);
    }
    else
    {
        $vb_fix = str_replace($id.'_'.$s.'-', 'https://'.$cdn.'/jiotv.live.cdn.jio.com/'.$id.'/'.$id.'_'.$s.'-', $vb_fix);
    }
    header("Content-Type: application/vnd.apple.mpegurl");
    print($vb_fix);
}

?>

