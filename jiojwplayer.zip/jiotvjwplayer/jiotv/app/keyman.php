<?php

header("Access-Control-Allow-Origin: *");
if(!function_exists('jio_token'))
{
    include('cmn.configs.php');
}

$s = ""; $k = ""; $id = ""; $token = "";
if(isset($_GET['s'])){ $s = $_GET['s']; }
if(isset($_GET['k'])){ $k = $_GET['k']; }
if(isset($_GET['id'])){ $id = $_GET['id']; }
if(isset($_GET['token'])){ $token = $_GET['token']; }

if(empty($s))
{
    http_response_code(400); exit();
}

if(empty($id))
{
    http_response_code(400); exit();
}

validateToken($id, $token);

$key_cache_file = 'key_cache/'.$id.'_'.$s.'-'.$k;
if(file_exists($key_cache_file))
{
    header("Content-Type: application/octet-stream");
    $keyme = @file_get_contents($key_cache_file);
    exit($keyme);
}

if(empty($JIO_AUTH))
{
    http_response_code(401);
    exit('License Server Auth Instance Not Available');
}

$keyurl = 'https://tv.media.jio.com/streams_live/'.$id.'/'.$id.'_'.$s.'-'.$k.'?'.jio_token().'&secversion=';
$keyheads = array('appkey: NzNiMDhlYzQyNjJm',
                  'channelid: 0',
                  'crmid: '.$JIO_AUTH['user']['subscriberId'],
                  'deviceId: '.$ANDROID_ID,
                  'devicetype: phone',
                  'isott: true',
                  'languageId: 6',
                  'lbcookie: 1',
                  'os: android',
                  'osVersion: 5.1.1',
                  'srno: 200206173037',
                  'ssotoken: '.$JIO_AUTH['ssotoken'],
                  'subscriberId: '.$JIO_AUTH['user']['subscriberId'],
                  'uniqueId: '.$JIO_AUTH['user']['unique'],
                  'User-Agent: plaYtv/6.0.9 (Linux; Android 5.1.1) ExoPlayerLib/2.13.2',
                  'usergroup: tvYR7NSNn7rymo3F',
                  'versionCode: 260');
$process = curl_init($keyurl);
curl_setopt($process, CURLOPT_HTTPHEADER, $keyheads);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_ENCODING, '');
curl_setopt($process, CURLOPT_TIMEOUT, 15);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
$return = curl_exec($process);
$dinfo = curl_getinfo($process);
curl_close($process);

if($dinfo['http_code'] == 200)
{
    if(!is_dir('key_cache'))
    {
        mkdir('key_cache');
    }
    header("Content-Type: application/octet-stream");
    @file_put_contents($key_cache_file, $return);
    print($return);
    exit();
}


?>
<?php

header("Access-Control-Allow-Origin: *");
if(!function_exists('jio_token'))
{
    include('cmn.configs.php');
}

$s = ""; $k = ""; $id = ""; $token = "";
if(isset($_GET['s'])){ $s = $_GET['s']; }
if(isset($_GET['k'])){ $k = $_GET['k']; }
if(isset($_GET['id'])){ $id = $_GET['id']; }
if(isset($_GET['token'])){ $token = $_GET['token']; }

if(empty($s))
{
    http_response_code(400); exit();
}

if(empty($id))
{
    http_response_code(400); exit();
}

validateToken($id, $token);

$key_cache_file = 'key_cache/'.$id.'_'.$s.'-'.$k;
if(file_exists($key_cache_file))
{
    header("Content-Type: application/octet-stream");
    $keyme = @file_get_contents($key_cache_file);
    exit($keyme);
}

if(empty($JIO_AUTH))
{
    http_response_code(401);
    exit('License Server Auth Instance Not Available');
}

$keyurl = 'https://tv.media.jio.com/streams_live/'.$id.'/'.$id.'_'.$s.'-'.$k.'?'.jio_token().'&secversion=';
$keyheads = array('appkey: NzNiMDhlYzQyNjJm',
                  'channelid: 0',
                  'crmid: '.$JIO_AUTH['user']['subscriberId'],
                  'deviceId: '.$ANDROID_ID,
                  'devicetype: phone',
                  'isott: true',
                  'languageId: 6',
                  'lbcookie: 1',
                  'os: android',
                  'osVersion: 5.1.1',
                  'srno: 200206173037',
                  'ssotoken: '.$JIO_AUTH['ssotoken'],
                  'subscriberId: '.$JIO_AUTH['user']['subscriberId'],
                  'uniqueId: '.$JIO_AUTH['user']['unique'],
                  'User-Agent: plaYtv/6.0.9 (Linux; Android 5.1.1) ExoPlayerLib/2.13.2',
                  'usergroup: tvYR7NSNn7rymo3F',
                  'versionCode: 260');
$process = curl_init($keyurl);
curl_setopt($process, CURLOPT_HTTPHEADER, $keyheads);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_ENCODING, '');
curl_setopt($process, CURLOPT_TIMEOUT, 15);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
$return = curl_exec($process);
$dinfo = curl_getinfo($process);
curl_close($process);

if($dinfo['http_code'] == 200)
{
    if(!is_dir('key_cache'))
    {
        mkdir('key_cache');
    }
    header("Content-Type: application/octet-stream");
    @file_put_contents($key_cache_file, $return);
    print($return);
    exit();
}


?>
<?php

header("Access-Control-Allow-Origin: *");
if(!function_exists('jio_token'))
{
    include('cmn.configs.php');
}

$s = ""; $k = ""; $id = ""; $token = "";
if(isset($_GET['s'])){ $s = $_GET['s']; }
if(isset($_GET['k'])){ $k = $_GET['k']; }
if(isset($_GET['id'])){ $id = $_GET['id']; }
if(isset($_GET['token'])){ $token = $_GET['token']; }

if(empty($s))
{
    http_response_code(400); exit();
}

if(empty($id))
{
    http_response_code(400); exit();
}

validateToken($id, $token);

$key_cache_file = 'key_cache/'.$id.'_'.$s.'-'.$k;
if(file_exists($key_cache_file))
{
    header("Content-Type: application/octet-stream");
    $keyme = @file_get_contents($key_cache_file);
    exit($keyme);
}

if(empty($JIO_AUTH))
{
    http_response_code(401);
    exit('License Server Auth Instance Not Available');
}

$keyurl = 'https://tv.media.jio.com/streams_live/'.$id.'/'.$id.'_'.$s.'-'.$k.'?'.jio_token().'&secversion=';
$keyheads = array('appkey: NzNiMDhlYzQyNjJm',
                  'channelid: 0',
                  'crmid: '.$JIO_AUTH['user']['subscriberId'],
                  'deviceId: '.$ANDROID_ID,
                  'devicetype: phone',
                  'isott: true',
                  'languageId: 6',
                  'lbcookie: 1',
                  'os: android',
                  'osVersion: 5.1.1',
                  'srno: 200206173037',
                  'ssotoken: '.$JIO_AUTH['ssotoken'],
                  'subscriberId: '.$JIO_AUTH['user']['subscriberId'],
                  'uniqueId: '.$JIO_AUTH['user']['unique'],
                  'User-Agent: plaYtv/6.0.9 (Linux; Android 5.1.1) ExoPlayerLib/2.13.2',
                  'usergroup: tvYR7NSNn7rymo3F',
                  'versionCode: 260');
$process = curl_init($keyurl);
curl_setopt($process, CURLOPT_HTTPHEADER, $keyheads);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_ENCODING, '');
curl_setopt($process, CURLOPT_TIMEOUT, 15);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
$return = curl_exec($process);
$dinfo = curl_getinfo($process);
curl_close($process);

if($dinfo['http_code'] == 200)
{
    if(!is_dir('key_cache'))
    {
        mkdir('key_cache');
    }
    header("Content-Type: application/octet-stream");
    @file_put_contents($key_cache_file, $return);
    print($return);
    exit();
}


?>
