<?php

header("Access-Control-Allow-Origin: *");
if(!function_exists('jio_token'))
{
    include('cmn.configs.php');
}

$id = "";
$ience = "";

if(isset($_GET['id']))
{
    $id = $_GET['id'];
}
if(empty($id))
{
    http_response_code(400);
    exit();
}

validateToken($id, $_GET['token']);

$playurl = 'https://jiotv.live.cdn.jio.com/'.$id.'/'.$id.'_TAB.m3u8';
$playhead = array('User-Agent: KAIOS');
$process = curl_init($playurl);
curl_setopt($process, CURLOPT_HTTPHEADER, $playhead);
curl_setopt($process, CURLOPT_HEADER, 0);
curl_setopt($process, CURLOPT_ENCODING, '');
curl_setopt($process, CURLOPT_TIMEOUT, 15);
curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
$myplayz = curl_exec($process);
$emiurl = curl_getinfo($process);
curl_close($process);
if(stripos($myplayz, '#EXTM3U') !== false)
{
    $unosu = parse_url($emiurl['url']);
    $cdnserver = $unosu['host'];

    $line = explode(PHP_EOL, $myplayz);
    foreach($line as $wine)
    {
        if(stripos($wine, '.m3u8') !== false)
        {
            $onomi = 'playlist.php?e=.m3u8&token='.$_GET['token'].'&cdn='.$cdnserver.'&id='.$id.'&s=';
            $ience .= str_replace($id.'_', $onomi, str_replace('.m3u8', '', $wine)).PHP_EOL;
        }
        else
        {
            $ience .= $wine.PHP_EOL;
        }
    }
    header("Content-Type: application/vnd.apple.mpegurl");
    print(trim($ience));
}


?>