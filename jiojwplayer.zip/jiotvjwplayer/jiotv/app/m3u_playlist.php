<?php

if(!function_exists('android_id'))
{
    include('cmn.configs.php');
}

$getikd = hideit('decrypt', @file_get_contents('_chndata'));
if(!empty($getikd))
{
    $ivbz = @json_decode($getikd, true);
    if(!empty($ivbz))
    {
        $channelsList = $ivbz;
    }
}

if(empty($channelsList))
{
    api_res('error', 500, 'Unable To Generate Playlist. Reason: Channel List Is Empty.', $data);
}

$local_ip = getHostByName(php_uname('n'));
if($_SERVER['SERVER_ADDR'] !== "127.0.0.1"){ $plhoth = $_SERVER['HTTP_HOST']; }else{ $plhoth = $local_ip; }

$playlistData .= '#EXTM3U'.PHP_EOL;
$v = 0;
foreach($channelsList as $mere)
{
    $v++;
    $playlistData .= '#EXTINF:-1 tvg-id="'.$mere['id'].'" tvg-name="'.$mere['title'].'" tvg-country="IN" tvg-logo="'.$mere['logo'].'" tvg-chno="'.$v.'" group-title="'.$mere['category'].' - '.$mere['language'].'",'.$mere['title'].PHP_EOL;
    $playlistData .= 'http://'.$plhoth.':'.$_SERVER['SERVER_PORT'].str_replace(" ", "%20", trim(str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']).'master.php?id='.$mere['id'].'&e=.m3u8')).PHP_EOL;
}    

$playlist_path = 'playintv.m3u';
if(file_put_contents($playlist_path, trim($playlistData)))
{
    api_res('success', 200, 'Playlist Generated Successfully', array('playlist_link' => 'http://'.$plhoth.':'.$_SERVER['SERVER_PORT'].str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']).$playlist_path.'?v='.time())));
}
else
{
    api_res('error', 500, 'Unable To Generate Playlist. Reason: File Permission Missing', $data);
}

?>